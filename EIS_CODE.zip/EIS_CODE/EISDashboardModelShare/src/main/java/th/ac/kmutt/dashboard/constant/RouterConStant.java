package th.ac.kmutt.dashboard.constant;

public class RouterConStant {
    public static final String USER_ENDPOINT = "userProfile";

}
